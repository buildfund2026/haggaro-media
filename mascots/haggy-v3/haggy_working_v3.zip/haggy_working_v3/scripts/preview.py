from lib import *
from finalize_common import *
from PIL import ImageDraw, ImageFont
INTER="/usr/share/fonts/truetype/sand-box/google/Inter/Inter-VariableFont_opsz,wght.ttf"
f=ImageFont.truetype(INTER,22)
S=720
y,x=np.mgrid[0:S,0:S]; c=((x//24+y//24)%2).astype(np.float32)
bg=np.dstack([0.86+0.08*c]*3)
seq=[('neutral',14),('blink_half',1),('blink_closed',2),('blink_half',1),('neutral',12),
 ('look_left',10),('neutral',3),('look_right',10),('neutral',8),
 ('wave_0',2),('wave_1',2),('wave_2',2),('wave_3',2),('wave_4',2),('wave_3',2),('wave_4',2),('wave_3',2),('wave_2',2),('wave_1',2),('wave_0',2),('neutral',10),
 ('happy',9),('laugh',9),('neutral',4),('wink',7),('neutral',4),('surprised',7),('happy',7),('neutral',4),('thinking',14),('neutral',4),('sad',9),('neutral',4),('heart',9),
 ('neutral',8),('blink_half',1),('blink_closed',2),('blink_half',1),('neutral',8)]
cache={}
i=0
for n,k in seq:
    if n not in cache:
        a=np.asarray(Image.open(f'{V3}/haggy_{n}.png').convert('RGBA').resize((S,S),Image.LANCZOS)).astype(np.float32)/255
        rgb=a[...,:3]*a[...,3:4]+bg*(1-a[...,3:4])
        im=Image.fromarray((rgb*255).astype(np.uint8)); d=ImageDraw.Draw(im)
        d.rectangle([0,S-40,S,S],fill=(30,24,40)); d.text((14,S-34),f'haggy_{n}.png   ·   pose set v3 preview (frame swap only, 12 fps)',font=f,fill=(235,230,250))
        cache[n]=im
    for _ in range(k):
        cache[n].save(f'pv/f{i:04d}.png'); i+=1
print(i)
