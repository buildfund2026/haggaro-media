# Haggy — official pose set

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

Creative development only. These files are for the login-page preview and animation work (spec-c).
Nothing is to be published, pushed, integrated, or deployed until the founder approves that step.
Coming 2027.

## Files

Each pose is a 1024×1024 32-bit sRGB PNG with a transparent background: no card, no ground shadow, no outer glow.
Names are lower_snake, character first.

- `haggy_neutral.png` — Neutral / Idle
- `haggy_blink_half.png` — Blink half
- `haggy_blink_closed.png` — Blink closed
- `haggy_look_left.png` — Look left
- `haggy_look_right.png` — Look right
- `haggy_wave_0.png` — Wave 0 (in-between)
- `haggy_wave_1.png` — Wave 1, start
- `haggy_wave_2.png` — Wave 2, mid
- `haggy_wave_3.png` — Wave 3, peak
- `haggy_wave_4.png` — Wave 4, swing
- `haggy_happy.png` — Happy smile
- `haggy_laugh.png` — Big laugh
- `haggy_wink.png` — Wink
- `haggy_surprised.png` — Surprised
- `haggy_thinking.png` — Thinking
- `haggy_sad.png` — Sad (held for later)
- `haggy_heart.png` — Love / heart eyes (held for later)

Working file: `haggy_working.ora` (one layer per pose).
Contact sheet: `haggy_poses_sheet.png`.

## Registration

Canvas 1024×1024, never trimmed. Feet or base rest on y=960 (64 px from the bottom) unless a 48 px top margin would be broken (noted below).
The page does the travelling. Body-changing poses stay planted on that baseline.

## Package registration notes (copies only)

Approved source masters were not rewritten. Fixes below were applied only to the files in this package.

- Copied from the approved Haggy v3 set. Already on y=960 with 0 px silhouette drift on face poses. No registration snap required.

## Set notes

Includes haggy_wave_0 (requested in-between) and the held sad / heart frames.

## Idle measurement in this package

- Idle file: `haggy_neutral.png`
- Foot / base y: 960 (spec target 960)
- Silhouette mean x: 487.8 (canvas centre 512)
- Margins L/T/R/B: (142, 144, 142, 63)

