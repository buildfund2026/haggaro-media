import numpy as np
ORDER=['haggy_neutral','haggy_blink_half','haggy_blink_closed','haggy_look_left','haggy_look_right',
 'haggy_wave_0','haggy_wave_1','haggy_wave_2','haggy_wave_3','haggy_wave_4',
 'haggy_happy','haggy_laugh','haggy_wink','haggy_surprised','haggy_thinking','haggy_sad','haggy_heart']
V2NAME={'haggy_neutral':'haggy_eyes_open','haggy_blink_half':'haggy_eyes_half','haggy_blink_closed':'haggy_eyes_closed','haggy_heart':'haggy_heart_eyes'}
LABEL={'haggy_neutral':'Neutral / idle','haggy_blink_half':'Blink half','haggy_blink_closed':'Blink closed','haggy_look_left':'Look left','haggy_look_right':'Look right',
 'haggy_wave_0':'Wave 0 (new)','haggy_wave_1':'Wave 1 start','haggy_wave_2':'Wave 2 mid','haggy_wave_3':'Wave 3 peak','haggy_wave_4':'Wave 4 swing',
 'haggy_happy':'Happy','haggy_laugh':'Laugh','haggy_wink':'Wink','haggy_surprised':'Surprised','haggy_thinking':'Thinking','haggy_sad':'Sad (held)','haggy_heart':'Heart eyes (held)'}
V3='/workspace/haggaro-marketing/mascots/haggy-master/v3'
def ishift(a,dx,dy):
    o=np.zeros_like(a); H,W=a.shape[:2]
    o[max(dy,0):H+min(dy,0),max(dx,0):W+min(dx,0)]=a[max(-dy,0):H-max(dy,0),max(-dx,0):W-max(dx,0)]
    return o
