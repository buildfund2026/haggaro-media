import json
from lib import *
from finalize_common import *
S=json.load(open('shift.json')); DX,DY=S['dx'],S['dy']
N2=load(SRC+'haggy_eyes_open.png')
Y,X=np.mgrid[0:1024,0:1024]
# exclusion = neutral visor + every arm/face change mask (v2 coords)
excl=cv2.dilate(visor_mask(N2).astype(np.uint8),np.ones((21,21),np.uint8)).astype(bool)
for n in ['thinking','wave_0','wave_1','wave_2','wave_3','wave_4']:
    excl|=np.load(f'maskf_{n}.npy')>0.01
excl=cv2.dilate(excl.astype(np.uint8),np.ones((15,15),np.uint8)).astype(bool)
sil=cv2.dilate((N2[...,3]>0.05).astype(np.uint8),np.ones((15,15),np.uint8)).astype(bool)
REG={'head':(Y>=130)&(Y<=570),'torso':(Y>=570)&(Y<=760)&(X>=330)&(X<=760),'feet':(Y>=760)&(Y<=975)}
def g(a):
    rgb=a[...,:3]*a[...,3:4]+0.5*(1-a[...,3:4])
    return cv2.cvtColor((rgb*255).astype(np.uint8),cv2.COLOR_RGB2GRAY).astype(np.float32)/255*0.6+0.4*a[...,3]
def meas(ref,mov,dx=0,dy=0):
    r=g(ref); m=g(mov); out={}
    for k,f in REG.items():
        msk=ishift((f&sil&~excl).astype(np.uint8)[...,None],dx,dy)[...,0]
        try:
            w=ecc(r,m,msk); out[k]=[round(float(w[0,2]),2),round(float(w[1,2]),2),round(float(np.hypot(w[0,2],w[1,2])),2)]
        except Exception as e: out[k]=None
    return out
res={}
N3=load(f'{V3}/haggy_neutral.png')
for n in ORDER:
    r={}
    if n!='haggy_wave_0':
        r['before_v2']=meas(N2,load(SRC+V2NAME.get(n,n)+'.png'))
    a=load(f'{V3}/{n}.png')
    r['after_v3']=meas(N3,a,DX,DY)
    # pixel identity outside change region
    d=np.abs((a*255).round()-(N3*255).round()).max(-1)
    body=N3[...,3]>0
    changed=(d>0)
    r['pixels_differing_from_neutral']=int(changed.sum())
    r['pct_of_silhouette_identical']=round(100*(1-(changed&(body|(a[...,3]>0))).sum()/max(1,(body|(a[...,3]>0)).sum())),2)
    ys,xs=np.nonzero(changed)
    r['changed_bbox']=[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())] if len(xs) else None
    res[n]=r
    fm=lambda v:'n/a' if v is None else f'{v[2]:.2f}'
    b=r.get('before_v2'); af=r['after_v3']
    print(n.ljust(20),'before',{k:fm(v) for k,v in b.items()} if b else '-','| after',{k:fm(v) for k,v in af.items()},'| ident%',r['pct_of_silhouette_identical'],r['changed_bbox'])
json.dump(res,open('metrics.json','w'),indent=1)
