Haggy + Crew — official pose package v1
For Claude, per spec-c (Haggy and the Crew: animation asset spec, version 2, 16 Nov 2026).

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

CREATIVE DEVELOPMENT ONLY. This package is for preview and animation work. Do not publish, push, integrate, or deploy these files, and do not put them in the live app, until the founder approves that step. Coming 2027.


What is included
----------------
One folder per character, lower_snake names, 1024×1024 32-bit transparent sRGB PNGs:

  haggy/   17 poses from the approved Haggy v3 set, including wave_0 and the held sad / heart frames
  lumy/    10 poses (shared set + dim / bright)
  vee/     11 poses (shared set except look_left / look_right, plus wink and approved extras)
  spike/   6 poses + spike_glasses_up.png alias
  chilly/  11 poses (shared set + shiver_1 / shiver_2 / door_open)
  click/   11 poses (shared set + wink / flash_1 / flash_2)
  pixel/   10 poses (shared set + cheer / buttons_lit)
  kicks/   13 poses (shared set + squash / air / run_1 / run_2 / run_3)
  boxy/    6 poses + boxy_neutral.png alias

Each folder also has:
  - a working .ora (one layer per pose)
  - a short README.md listing the poses
  - a per-character contact sheet ( <name>_poses_sheet.png )

This zip also has:
  - haggy_crew_full_v1_review_sheet.png  (all characters' poses together)
  - this note


Naming
------
lower_snake, character first, as in spec-c. Examples: haggy_blink_closed.png, lumy_dim.png, click_flash_2.png.

Spec-c name aliases (identical pixels, so either name can be used):
  - spike_glasses_up.png  = spike_sunglasses_up.png  (approved file used the longer name)
  - boxy_neutral.png      = boxy_happy.png           (approved resting face is the official happy smile)

Vee: vee_blink_open.png is identical to vee_neutral.png.


Spec-c compliance
-----------------
- Format: PNG, 32-bit with transparency. No background, no card, no ground shadow, no outer glow.
- Canvas: 1024×1024 for every frame. Not cropped or trimmed.
- Placement: feet or base on y=960 (64 px from the bottom), at least 48 px clear on the other three sides, in every packaged frame.
- Flip test: face-locked frames share one locked body. Haggy v3 and the five later crew (Lumy, Click, Pixel, Kicks, Chilly) already did this. Vee's cabinet was locked in this package by compositing the approved screen faces onto the official hero body. Spike's pot and Boxy's box base were translated in this package so copies line up; moving parts (glasses, flaps) still change, as they should.
- The page does the travelling. Squash / air / shiver / run / door / wave stay on the same baseline; they do not hop the canvas to fake a jump.
- Working files are included.

Known gaps and judgment calls (not invented)
--------------------------------------------
Vee: no look_left, look_right, sleepy, or static in the approved set.
Spike: blink and look are skipped (spec-c allows this when sunglasses hide the eyes). laugh, adjust, and grin were not in the approved set.
Boxy: no separate blink / look / laugh; official resting face is the painted happy smile (boxy_neutral is that same file). Flaps-open, closed, and peek are different takes of moving flaps; package copies were translated onto the shared baseline, but remaining scale/shape difference around the flaps was not resampled, so as not to alter the approved artwork.
Lumy: idle was snapped 2 px so the base sits on y=960; the 48 px top margin still holds (it gets looser when the character moves down).
Pixel: hero is a front view (the official cutout is also front). Generic two-dot mark, not a real console logo.

Package registration fixes (copies only)
----------------------------------------
Approved source masters in crew-master/<name>/ and haggy-master/ were not rewritten.
  haggy: Copied from the approved Haggy v3 set. Already on y=960 with 0 px silhouette drift on face poses. No registration snap required.
  vee: Official hero cabinet (vee_happy) snapped by dy=2 so the base sits on y=960.
  vee: Face poses were composited onto the locked vee_happy cabinet (v3 method, copies only) so non-moving cabinet/legs/antenna match the hero pixel-for-pixel. Screen faces are the approved expressions.
  vee: vee_blink_open is identical to vee_neutral.
  spike: Official hero (spike_sunglasses_on) snapped by dy=1 so the pot base sits on y=960.
  spike: Package copies were translated so the pot (the non-moving lock) lines up with the official hero and the base sits on y=960. Integer shifts: {'spike_neutral': (4, -2), 'spike_happy': (5, -2), 'spike_surprised': (5, 2), 'spike_sunglasses_down': (8, 1), 'spike_sunglasses_up': (7, 0)}. Artwork was not redrawn or rescaled. Sunglasses-down / up are moving-part poses, so residual silhouette difference around the glasses is expected.
  boxy: Official hero (boxy_happy) snapped by dy=1 so the box base sits on y=960.
  boxy: Package copies were translated so each pose's box base sits on y=960 and lines up horizontally with the official hero base. Integer shifts: {'boxy_surprised': (-5, 5), 'boxy_closed': (-32, -2), 'boxy_flaps_half': (-5, 11), 'boxy_flaps_open': (-50, 3), 'boxy_peek': (-55, 11)}. Artwork was not redrawn. Flaps-open / closed / peek change the silhouette (moving flaps), so some remaining scale/shape difference vs the happy cube is expected and was not resampled.
  lumy: Face-locked set shifted by dy=2 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).
  click: Face-locked set shifted by dy=1 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).
  click: click_flash_1 snapped by dy=2 so the base sits on y=960.
  click: click_flash_2 snapped by dy=2 so the base sits on y=960.
  pixel: Face-locked set shifted by dy=1 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).
  kicks: Face-locked set shifted by dy=1 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).
  kicks: kicks_squash snapped by dy=1 so the base sits on y=960.
  kicks: kicks_run_1 snapped by dy=2 so the base sits on y=960.
  kicks: kicks_run_2 snapped by dy=1 so the base sits on y=960.
  kicks: kicks_run_3 snapped by dy=1 so the base sits on y=960.
  chilly: Face-locked set shifted by dy=2 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).
  chilly: chilly_shiver_1 snapped by dy=1 so the base sits on y=960.
  chilly: chilly_shiver_2 snapped by dy=1 so the base sits on y=960.
  chilly: chilly_door_open snapped by dy=2 so the base sits on y=960.

Idle measurements in this package
---------------------------------
  haggy   idle=haggy_neutral.png  foot_y=960  cx=487.8  margins=(142, 144, 142, 63)
  vee     idle=vee_neutral.png  foot_y=960  cx=507.9  margins=(151, 59, 162, 63)
  spike   idle=spike_sunglasses_on.png  foot_y=960  cx=527.8  margins=(214, 58, 160, 63)
  boxy    idle=boxy_happy.png  foot_y=960  cx=475.1  margins=(74, 118, 90, 63)
  lumy    idle=lumy_happy.png  foot_y=960  cx=511.9  margins=(241, 50, 199, 63)
  click   idle=click_happy.png  foot_y=960  cx=507.6  margins=(49, 226, 48, 63)
  pixel   idle=pixel_happy.png  foot_y=960  cx=514.8  margins=(49, 296, 49, 63)
  kicks   idle=kicks_happy.png  foot_y=960  cx=512.5  margins=(103, 50, 188, 63)
  chilly  idle=chilly_happy.png  foot_y=960  cx=511.3  margins=(220, 78, 219, 63)


How to use
----------
Load each character's folder of 1024 PNGs. Use the README and the contact sheet in that folder, or the combined review sheet, to check identity against the approved designs. Use the .ora if you need layers. Keep the transparent background. The product page should add any glow or motion; the frames themselves should not.


Nothing in this package is a launch, a live build, or an instruction to ship.
