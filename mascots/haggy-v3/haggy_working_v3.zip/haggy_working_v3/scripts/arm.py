from lib import *
N=load(SRC+'haggy_eyes_open.png')
Y,X=np.mgrid[0:1024,0:1024]
def g(a):
    rgb=a[...,:3]*a[...,3:4]+0.5*(1-a[...,3:4])
    return cv2.cvtColor((rgb*255).astype(np.uint8),cv2.COLOR_RGB2GRAY).astype(np.float32)/255*0.6+0.4*a[...,3]
def body_mask():
    m=(Y>=560)&(Y<=975)&~((X>660)&(Y<780))
    return m & (cv2.dilate((N[...,3]>0.05).astype(np.uint8),np.ones((15,15)))>0)
def register(a,mode=cv2.MOTION_AFFINE,mask=None):
    if mask is None: mask=body_mask()
    w=ecc(g(N),g(a),mask,mode)
    # w maps ref coords -> mov coords; warp mov into ref frame with WARP_INVERSE_MAP
    pm=a.copy(); pm[...,:3]*=pm[...,3:4]
    o=cv2.warpAffine(pm,w,(1024,1024),flags=cv2.INTER_LANCZOS4|cv2.WARP_INVERSE_MAP)
    o=np.clip(o,0,1); al=o[...,3:4]
    o[...,:3]=np.where(al>1e-4,o[...,:3]/np.maximum(al,1e-4),0)
    return np.clip(o,0,1),w
if __name__=='__main__':
    for n in ['thinking','wave_1','wave_2','wave_3','wave_4']:
        a=load(SRC+f'haggy_{n}.png')
        o,w=register(a)
        print(n,np.round(w,4).tolist())
        save(o,f'reg_{n}.png')
        d=np.abs(o-N).max(-1)
        Image.fromarray((np.clip(d*3,0,1)*255).astype(np.uint8)).save(f'/tmp/diff_{n}.png')
