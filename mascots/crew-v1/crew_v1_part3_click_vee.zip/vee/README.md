# Vee — official pose set

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

Creative development only. These files are for the login-page preview and animation work (spec-c).
Nothing is to be published, pushed, integrated, or deployed until the founder approves that step.
Coming 2027.

## Files

Each pose is a 1024×1024 32-bit sRGB PNG with a transparent background: no card, no ground shadow, no outer glow.
Names are lower_snake, character first.

- `vee_neutral.png` — Neutral / Idle (open ovals)
- `vee_blink_half.png` — Blink half
- `vee_blink_closed.png` — Blink closed
- `vee_happy.png` — Happy (official face / hero)
- `vee_laugh.png` — Laugh
- `vee_surprised.png` — Surprised
- `vee_wink.png` — Wink (own pose)
- `vee_sad.png` — Sad (approved extra)
- `vee_heart_eyes.png` — Heart eyes (approved extra)
- `vee_thinking.png` — Thinking (approved extra)
- `vee_blink_open.png` — Blink open (identical to neutral)

Working file: `vee_working.ora` (one layer per pose).
Contact sheet: `vee_poses_sheet.png`.

## Registration

Canvas 1024×1024, never trimmed. Feet or base rest on y=960 (64 px from the bottom) unless a 48 px top margin would be broken (noted below).
The page does the travelling. Body-changing poses stay planted on that baseline.

## Package registration notes (copies only)

Approved source masters were not rewritten. Fixes below were applied only to the files in this package.

- Official hero cabinet (vee_happy) snapped by dy=2 so the base sits on y=960.
- Face poses were composited onto the locked vee_happy cabinet (v3 method, copies only) so non-moving cabinet/legs/antenna match the hero pixel-for-pixel. Screen faces are the approved expressions.
- vee_blink_open is identical to vee_neutral.

## Set notes

Approved extras beyond the spec-c shared+own list: sad, heart_eyes, thinking. vee_blink_open is a byte-identical copy of vee_neutral.

## Skipped (not invented)

- vee_look_left / vee_look_right — not in the approved Vee set; not invented.
- vee_sleepy / vee_static — listed in spec-c as Vee's own poses, not in the approved set; not invented.

## Idle measurement in this package

- Idle file: `vee_neutral.png`
- Foot / base y: 960 (spec target 960)
- Silhouette mean x: 507.9 (canvas centre 512)
- Margins L/T/R/B: (151, 59, 162, 63)

