# Click — official pose set

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

Creative development only. These files are for the login-page preview and animation work (spec-c).
Nothing is to be published, pushed, integrated, or deployed until the founder approves that step.
Coming 2027.

## Files

Each pose is a 1024×1024 32-bit sRGB PNG with a transparent background: no card, no ground shadow, no outer glow.
Names are lower_snake, character first.

- `click_neutral.png` — Neutral / Idle
- `click_blink_half.png` — Blink half
- `click_blink_closed.png` — Blink closed
- `click_look_left.png` — Look left
- `click_look_right.png` — Look right
- `click_happy.png` — Happy (official face / hero)
- `click_laugh.png` — Laugh
- `click_surprised.png` — Surprised
- `click_wink.png` — Wink (aiming)
- `click_flash_1.png` — Flash 1 (pre-flash)
- `click_flash_2.png` — Flash 2 (burst)

Working file: `click_working.ora` (one layer per pose).
Contact sheet: `click_poses_sheet.png`.

## Registration

Canvas 1024×1024, never trimmed. Feet or base rest on y=960 (64 px from the bottom) unless a 48 px top margin would be broken (noted below).
The page does the travelling. Body-changing poses stay planted on that baseline.

## Package registration notes (copies only)

Approved source masters were not rewritten. Fixes below were applied only to the files in this package.

- Face-locked set shifted by dy=1 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).
- click_flash_1 snapped by dy=2 so the base sits on y=960.
- click_flash_2 snapped by dy=2 so the base sits on y=960.

## Set notes

Shared set plus wink and the two flash frames.

## Idle measurement in this package

- Idle file: `click_happy.png`
- Foot / base y: 960 (spec target 960)
- Silhouette mean x: 507.6 (canvas centre 512)
- Margins L/T/R/B: (49, 226, 48, 63)

