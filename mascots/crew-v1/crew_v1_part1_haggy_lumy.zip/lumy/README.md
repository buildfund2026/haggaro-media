# Lumy — official pose set

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

Creative development only. These files are for the login-page preview and animation work (spec-c).
Nothing is to be published, pushed, integrated, or deployed until the founder approves that step.
Coming 2027.

## Files

Each pose is a 1024×1024 32-bit sRGB PNG with a transparent background: no card, no ground shadow, no outer glow.
Names are lower_snake, character first.

- `lumy_neutral.png` — Neutral / Idle
- `lumy_blink_half.png` — Blink half
- `lumy_blink_closed.png` — Blink closed
- `lumy_look_left.png` — Look left
- `lumy_look_right.png` — Look right
- `lumy_happy.png` — Happy (official face / hero)
- `lumy_laugh.png` — Laugh
- `lumy_surprised.png` — Surprised
- `lumy_dim.png` — Dim
- `lumy_bright.png` — Bright

Working file: `lumy_working.ora` (one layer per pose).
Contact sheet: `lumy_poses_sheet.png`.

## Registration

Canvas 1024×1024, never trimmed. Feet or base rest on y=960 (64 px from the bottom) unless a 48 px top margin would be broken (noted below).
The page does the travelling. Body-changing poses stay planted on that baseline.

## Package registration notes (copies only)

Approved source masters were not rewritten. Fixes below were applied only to the files in this package.

- Face-locked set shifted by dy=2 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).

## Set notes

Shared set plus lumy_dim / lumy_bright. Official happy is the hero; neutral is open ovals with lashes.

## Idle measurement in this package

- Idle file: `lumy_happy.png`
- Foot / base y: 960 (spec target 960)
- Silhouette mean x: 511.9 (canvas centre 512)
- Margins L/T/R/B: (241, 50, 199, 63)

