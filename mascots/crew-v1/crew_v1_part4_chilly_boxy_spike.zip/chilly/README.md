# Chilly — official pose set

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

Creative development only. These files are for the login-page preview and animation work (spec-c).
Nothing is to be published, pushed, integrated, or deployed until the founder approves that step.
Coming 2027.

## Files

Each pose is a 1024×1024 32-bit sRGB PNG with a transparent background: no card, no ground shadow, no outer glow.
Names are lower_snake, character first.

- `chilly_neutral.png` — Neutral / Idle
- `chilly_blink_half.png` — Blink half
- `chilly_blink_closed.png` — Blink closed
- `chilly_look_left.png` — Look left
- `chilly_look_right.png` — Look right
- `chilly_happy.png` — Happy (official face / hero)
- `chilly_laugh.png` — Laugh
- `chilly_surprised.png` — Surprised
- `chilly_shiver_1.png` — Shiver 1 (in-place lean)
- `chilly_shiver_2.png` — Shiver 2 (in-place lean)
- `chilly_door_open.png` — Door open

Working file: `chilly_working.ora` (one layer per pose).
Contact sheet: `chilly_poses_sheet.png`.

## Registration

Canvas 1024×1024, never trimmed. Feet or base rest on y=960 (64 px from the bottom) unless a 48 px top margin would be broken (noted below).
The page does the travelling. Body-changing poses stay planted on that baseline.

## Package registration notes (copies only)

Approved source masters were not rewritten. Fixes below were applied only to the files in this package.

- Face-locked set shifted by dy=2 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).
- chilly_shiver_1 snapped by dy=1 so the base sits on y=960.
- chilly_shiver_2 snapped by dy=1 so the base sits on y=960.
- chilly_door_open snapped by dy=2 so the base sits on y=960.

## Set notes

Shared set plus two in-place shivers and door_open.

## Idle measurement in this package

- Idle file: `chilly_happy.png`
- Foot / base y: 960 (spec target 960)
- Silhouette mean x: 511.3 (canvas centre 512)
- Margins L/T/R/B: (220, 78, 219, 63)

