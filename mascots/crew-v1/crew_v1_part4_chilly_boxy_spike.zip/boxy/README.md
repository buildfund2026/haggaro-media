# Boxy — official pose set

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

Creative development only. These files are for the login-page preview and animation work (spec-c).
Nothing is to be published, pushed, integrated, or deployed until the founder approves that step.
Coming 2027.

## Files

Each pose is a 1024×1024 32-bit sRGB PNG with a transparent background: no card, no ground shadow, no outer glow.
Names are lower_snake, character first.

- `boxy_happy.png` — Happy (official face / hero / resting) — also packaged as boxy_neutral.png (spec-c name)
- `boxy_surprised.png` — Surprised
- `boxy_closed.png` — Flaps closed, face hidden
- `boxy_flaps_half.png` — Flaps half open (approved extra)
- `boxy_flaps_open.png` — Flaps wide open
- `boxy_peek.png` — Peek (eyes over the dropped front flap)
- `boxy_neutral.png` — spec-c name; identical pixels to `boxy_happy.png`.

Working file: `boxy_working.ora` (one layer per pose).
Contact sheet: `boxy_poses_sheet.png`.

## Registration

Canvas 1024×1024, never trimmed. Feet or base rest on y=960 (64 px from the bottom) unless a 48 px top margin would be broken (noted below).
The page does the travelling. Body-changing poses stay planted on that baseline.

## Package registration notes (copies only)

Approved source masters were not rewritten. Fixes below were applied only to the files in this package.

- Official hero (boxy_happy) snapped by dy=1 so the box base sits on y=960.
- Package copies were translated so each pose's box base sits on y=960 and lines up horizontally with the official hero base. Integer shifts: {'boxy_surprised': (-5, 5), 'boxy_closed': (-32, -2), 'boxy_flaps_half': (-5, 11), 'boxy_flaps_open': (-50, 3), 'boxy_peek': (-55, 11)}. Artwork was not redrawn. Flaps-open / closed / peek change the silhouette (moving flaps), so some remaining scale/shape difference vs the happy cube is expected and was not resampled.

## Set notes

boxy_neutral.png is a spec-c alias of the approved resting pose boxy_happy (identical pixels). boxy_flaps_half is an approved extra.

## Skipped (not invented)

- boxy_blink_half / blink_closed / look_left / look_right / laugh — not in the approved set; not invented. Official resting face is the painted happy smile.

## Idle measurement in this package

- Idle file: `boxy_happy.png`
- Foot / base y: 960 (spec target 960)
- Silhouette mean x: 475.1 (canvas centre 512)
- Margins L/T/R/B: (74, 118, 90, 63)

