import json
from lib import *
from finalize_common import *
out={}
for n in ORDER:
    a=load(f'{V3}/{n}.png'); al=a[...,3]
    solid=al>=0.9
    ring=cv2.dilate(solid.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(7,7))).astype(bool)
    stray=(al>0.004)&~ring              # anything beyond a 3px AA edge = shadow/glow/haze
    L=lum(a)
    semi=(al>0.004)&(al<0.9)
    dark_semi_under=semi&(L<0.25)&(np.arange(1024)[:,None]>=900)
    ys,xs=np.nonzero(al>0.004)
    ys9,xs9=np.nonzero(solid)
    border=np.concatenate([al[0],al[-1],al[:,0],al[:,-1]])
    rgb_in_clear=int((a[...,:3][al==0]>0).any(-1).sum())
    out[n]=dict(stray_px_beyond_3px_edge=int(stray.sum()),dark_semitransparent_px_below_y900=int(dark_semi_under.sum()),
        lowest_any_alpha_row=int(ys.max()),lowest_solid_row=int(ys9.max()),bbox_any=[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())],
        margins=dict(left=int(xs.min()),top=int(ys.min()),right=int(1023-xs.max()),bottom=int(1023-ys.max())),
        border_alpha_max=float(border.max()),rgb_left_in_fully_clear_px=rgb_in_clear,
        size=list(Image.open(f'{V3}/{n}.png').size),mode=Image.open(f'{V3}/{n}.png').mode)
    print(n.ljust(20),out[n])
# v2 surprised for comparison
a=load(SRC+'haggy_surprised.png'); al=a[...,3]; solid=al>=0.9
ring=cv2.dilate(solid.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(7,7))).astype(bool)
v2s={}
for nm in ['haggy_surprised','haggy_eyes_open']:
    a=load(SRC+nm+'.png'); al=a[...,3]; solid=al>=0.9
    ring=cv2.dilate(solid.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(7,7))).astype(bool)
    # shadow: opaque-ish gray pixels under the soles: low saturation, mid-dark, y>=900
    rgb=a[...,:3]; mx=rgb.max(-1); mn=rgb.min(-1); sat=np.where(mx>0,(mx-mn)/np.maximum(mx,1e-6),0)
    sh=(al>0.05)&(sat<0.2)&(lum(a)<0.45)&(np.arange(1024)[:,None]>=905)
    v2s[nm]=dict(stray=int(((al>0.004)&~ring).sum()),gray_dark_px_below_y905=int(sh.sum()))
for n in ORDER:
    a=load(f'{V3}/{n}.png'); al=a[...,3]; rgb=a[...,:3]; mx=rgb.max(-1); mn=rgb.min(-1); sat=np.where(mx>0,(mx-mn)/np.maximum(mx,1e-6),0)
    out[n]['gray_dark_px_below_y907']=int(((al>0.05)&(sat<0.2)&(lum(a)<0.45)&(np.arange(1024)[:,None]>=907)).sum())
print('v2',v2s); print({n:out[n]['gray_dark_px_below_y907'] for n in ORDER})
json.dump(dict(v3=out,v2_reference=v2s),open('shadowcheck.json','w'),indent=1)
