from lib import *
N=load(SRC+'haggy_eyes_open.png'); NV=visor_mask(N)
Y,X=np.mgrid[0:1024,0:1024]
names=['thinking','wave_1','wave_2','wave_3','wave_4']
R={n:load(f'reg_{n}.png') for n in names}
core=(N[...,3]>0.5)
for n in names: core&=(R[n][...,3]>0.5)
core=cv2.morphologyEx(core.astype(np.uint8),cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(25,25))).astype(bool)
coreD=cv2.dilate(core.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(9,9))).astype(bool)
def armpart(a):
    m=(a[...,3]>0.05)&~coreD&(X>560)&(Y>300)&(Y<880)
    m=cv2.morphologyEx(m.astype(np.uint8),cv2.MORPH_OPEN,np.ones((7,7),np.uint8))
    n_,lab,st,_=cv2.connectedComponentsWithStats(m)
    k=np.zeros(m.shape,bool)
    for i in range(1,n_):
        if st[i,cv2.CC_STAT_AREA]>1500: k|=lab==i
    return k
def ellipse(cx,cy,rx,ry):
    return ((X-cx)/rx)**2+((Y-cy)/ry)**2<=1
SHOULDER=ellipse(700,600,95,90)
masks={}
if __name__=='__main__':
    aN=armpart(N)
    tiles=[]
    for n in names:
        aR=armpart(R[n])
        m=aN|aR|SHOULDER
        if n=='thinking':
            m|=ellipse(640,560,110,90)
        m=cv2.dilate(m.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(25,25))).astype(bool)
        np.save(f'mask_{n}.npy',m)
        a=R[n]; rgb=(a[...,:3]*a[...,3:4]+0.85*(1-a[...,3:4]))
        e=m^cv2.erode(m.astype(np.uint8),np.ones((5,5))).astype(bool); rgb[e]=[0,1,0]
        c=core^cv2.erode(core.astype(np.uint8),np.ones((3,3))).astype(bool); rgb[c]=[1,0,0]
        tiles.append((rgb[250:950,350:1024]*255).astype(np.uint8))
    Image.fromarray(np.hstack(tiles)).resize((674*5//2,350)).save('/tmp/masks2.jpg')
