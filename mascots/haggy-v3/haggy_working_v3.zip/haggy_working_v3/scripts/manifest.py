import json, hashlib, os
from finalize_common import *
M=json.load(open('metrics.json')); S=json.load(open('shadowcheck.json')); SH=json.load(open('shift.json'))
METHOD={'face':'v2 pose: face (visor) pasted onto the idle frame; everything outside the face is the idle frame pixel for pixel',
 'arm':'v2 pose: right arm/hand pasted onto the idle frame (registered to the idle body); head, face, torso, legs, left paw are the idle frame pixel for pixel',
 'face+arm':'v2 pose: face + right arm/hand-on-chin pasted onto the idle frame; everything else is the idle frame pixel for pixel',
 'none':'registration master (v2 haggy_eyes_open)'}
KIND={n:'face' for n in ORDER}; KIND['haggy_neutral']='none'
for n in ['haggy_wave_0','haggy_wave_1','haggy_wave_2','haggy_wave_3','haggy_wave_4']: KIND[n]='arm'
KIND['haggy_thinking']='face+arm'
frames=[]
for n in ORDER:
    p=f'{V3}/{n}.png'; b=open(p,'rb').read()
    s=S['v3'][n]
    frames.append(dict(file=f'{n}.png',label=LABEL[n],source_v2=(V2NAME.get(n,n)+'.png') if n!='haggy_wave_0' else None,
        new_in_v3=n=='haggy_wave_0',method=METHOD[KIND[n]] if n!='haggy_wave_0' else 'NEW: arm from a new reference-based render of the approved idle + wave_1, pasted onto the idle frame; everything outside the arm is the idle frame pixel for pixel',
        used_on_page={'haggy_sad':False,'haggy_heart':False}.get(n,True),
        bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),bbox_alpha=s['bbox_any'],margins=s['margins'],
        changed_region_vs_neutral=M[n]['changed_bbox'],
        offset_vs_neutral_px_before_v2=M[n].get('before_v2'),offset_vs_neutral_px_after_v3=M[n]['after_v3'],
        shadow_check=dict(stray_alpha_px_beyond_3px_edge=s['stray_px_beyond_3px_edge'],gray_dark_px_below_y907=s['gray_dark_px_below_y907'],border_alpha_max=s['border_alpha_max'])))
man=dict(name='haggy-pose-set-v3',character='haggy',
 status='Creative prep only. Official master approved by founder 16 Nov 2026 (incl. small black backpack; round open eyes = idle, upward crescent eyes = happy). Pose set v3 awaits Claude QA in the separate preview and founder approval. Not for publication, integration or deployment.',
 spec='Haggy and the Crew: animation asset spec for Steve, version 2 (16 Nov 2026) incl. "Corrections requested on Pose Set v2"',
 canvas=dict(width=1024,height=1024,mode='RGBA 8-bit/channel (32-bit)',color_space='sRGB',background='fully transparent',card=False,ground_shadow=False,outer_glow=False),
 placement=dict(feet_line_y=960,lowest_solid_row=959,lowest_any_alpha_row=961,centre='idle frame alpha bbox centred on x=512 (x 140..882)',min_margins_px=dict(left=140,top=142,right=124,bottom=62),
   moved_vs_v2=dict(dx=SH['dx'],dy=SH['dy'],note='whole set moved by the same whole-pixel offset (lossless) to meet the spec: centred left to right, feet on the line 64 px above the bottom')),
 registration_method='haggy_neutral is the master. Every other frame is the neutral frame with only the changing part (face, or right arm/hand) replaced, so head, torso, legs, feet and left paw are pixel-identical to neutral in all 17 frames.',
 measurement_method='OpenCV ECC translation fit vs neutral on three regions (head excl. visor/face, torso, feet/legs), with all changing areas (face + every arm position) masked out. Before = v2 files vs v2 eyes_open; after = v3 files vs v3 neutral.',
 frames=frames,
 preview_loop='preview.mp4 (720x720, 12 fps, 17 s, checkerboard): idle, blink, look L/R, idle>wave_0>wave_1>2>3>4>3>4>3>2>1>wave_0>idle, expressions, thinking, sad, heart, blink',
 phone_sheet_estimate_kb=dict(webp_256_q80=150,webp_256_q90=211,png_256=372,target_kb=400),
 deliverables=dict(zip='haggy_poses_v3.zip (haggy/ + 17 PNGs only)',review_sheet='haggy_poses_v3_review_sheet.png',working_file='haggy_working_v3.ora (OpenRaster, one layer per pose; opens in Krita/GIMP)',source_package='haggy_working_v3.zip'))
json.dump(man,open(f'{V3}/manifest.json','w'),indent=1)
print('ok')
