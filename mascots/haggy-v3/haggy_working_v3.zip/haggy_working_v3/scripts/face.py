from lib import *
import sys, json
N=load(SRC+'haggy_eyes_open.png'); NV=visor_mask(N)
def face_swap(srcname, erode=7, fr=2.5):
    a=load(SRC+srcname)
    V=visor_mask(a)
    ref=feather(NV,3); mov=feather(V,3)
    w=ecc(ref,mov,np.ones_like(NV,np.uint8))
    dx,dy=float(w[0,2]),float(w[1,2])
    # ecc gives mapping ref->mov coords: mov(x+dx)=ref(x); so shift mov by -dx
    al=shift(a,-dx,-dy)
    V2=visor_mask(al)
    inter=(NV&V2).astype(np.uint8)
    inter=cv2.erode(inter,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*erode+1,2*erode+1)))
    m=feather(inter,fr)
    out=composite(N,al,m)
    return out,dict(visor_dx=-dx,visor_dy=-dy)
if __name__=='__main__':
    import os
    os.makedirs('frames',exist_ok=True)
    rep={}
    for dst,src in [('haggy_blink_half','haggy_eyes_half'),('haggy_blink_closed','haggy_eyes_closed'),('haggy_look_left','haggy_look_left'),('haggy_look_right','haggy_look_right'),('haggy_happy','haggy_happy'),('haggy_laugh','haggy_laugh'),('haggy_wink','haggy_wink'),('haggy_surprised','haggy_surprised'),('haggy_sad','haggy_sad'),('haggy_heart','haggy_heart_eyes')]:
        o,r=face_swap(src+'.png'); save(o,f'frames/{dst}.png'); rep[dst]=r; print(dst,r)
    save(N,'frames/haggy_neutral.png')
    json.dump(rep,open('face_report.json','w'),indent=1)
