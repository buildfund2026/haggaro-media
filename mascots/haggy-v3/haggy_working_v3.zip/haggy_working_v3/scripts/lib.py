import cv2, numpy as np
from PIL import Image
from scipy import ndimage as ndi
SRC='/workspace/haggaro-marketing/mascots/haggy-master/poses/'
def load(p):
    return np.asarray(Image.open(p).convert('RGBA')).astype(np.float32)/255
def save(a,p):
    Image.fromarray((np.clip(a,0,1)*255+0.5).astype(np.uint8),'RGBA').save(p,optimize=True)
def lum(a): return (a[...,:3]*[0.299,0.587,0.114]).sum(-1)
def visor_mask(a):
    # dark pixels in head area -> largest component -> fill holes
    d=(lum(a)<0.10)&(a[...,3]>0.9)
    d[600:]=False
    d=cv2.morphologyEx(d.astype(np.uint8),cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
    n,lab,st,_=cv2.connectedComponentsWithStats(d)
    i=1+np.argmax(st[1:,cv2.CC_STAT_AREA])
    m=(lab==i)
    m=cv2.morphologyEx(m.astype(np.uint8),cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(41,41)))
    m=ndi.binary_fill_holes(m)
    return m
def shift(a,dx,dy,scale=1.0,cx=512,cy=512):
    M=np.array([[scale,0,dx+cx*(1-scale)],[0,scale,dy+cy*(1-scale)]],np.float32)
    pm=a.copy(); pm[...,:3]*=pm[...,3:4]
    out=cv2.warpAffine(pm,M,(1024,1024),flags=cv2.INTER_LANCZOS4,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
    out=np.clip(out,0,1)
    al=out[...,3:4]
    out[...,:3]=np.where(al>1e-4,out[...,:3]/np.maximum(al,1e-4),0)
    return np.clip(out,0,1)
def ecc(ref,mov,mask,mode=cv2.MOTION_TRANSLATION):
    w=np.eye(2,3,dtype=np.float32)
    crit=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,300,1e-7)
    _,w=cv2.findTransformECC(ref.astype(np.float32),mov.astype(np.float32),w,mode,crit,mask.astype(np.uint8),5)
    return w
def composite(base,top,m):
    # premultiplied lerp
    m=m[...,None]
    pb=base.copy(); pb[...,:3]*=pb[...,3:4]
    pt=top.copy(); pt[...,:3]*=pt[...,3:4]
    o=pb*(1-m)+pt*m
    al=o[...,3:4]
    o[...,:3]=np.where(al>1e-4,o[...,:3]/np.maximum(al,1e-4),0)
    return np.clip(o,0,1)
def feather(m,r):
    return cv2.GaussianBlur(m.astype(np.float32),(0,0),r)
