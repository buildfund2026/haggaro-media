# Kicks — official pose set

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

Creative development only. These files are for the login-page preview and animation work (spec-c).
Nothing is to be published, pushed, integrated, or deployed until the founder approves that step.
Coming 2027.

## Files

Each pose is a 1024×1024 32-bit sRGB PNG with a transparent background: no card, no ground shadow, no outer glow.
Names are lower_snake, character first.

- `kicks_neutral.png` — Neutral / Idle
- `kicks_blink_half.png` — Blink half
- `kicks_blink_closed.png` — Blink closed
- `kicks_look_left.png` — Look left
- `kicks_look_right.png` — Look right
- `kicks_happy.png` — Happy (official face / hero)
- `kicks_laugh.png` — Laugh
- `kicks_surprised.png` — Surprised
- `kicks_squash.png` — Squash (in place)
- `kicks_air.png` — Air / toe-up (in place)
- `kicks_run_1.png` — Run 1 — contact
- `kicks_run_2.png` — Run 2 — passing
- `kicks_run_3.png` — Run 3 — extension

Working file: `kicks_working.ora` (one layer per pose).
Contact sheet: `kicks_poses_sheet.png`.

## Registration

Canvas 1024×1024, never trimmed. Feet or base rest on y=960 (64 px from the bottom) unless a 48 px top margin would be broken (noted below).
The page does the travelling. Body-changing poses stay planted on that baseline.

## Package registration notes (copies only)

Approved source masters were not rewritten. Fixes below were applied only to the files in this package.

- Face-locked set shifted by dy=1 so the idle base sits on y=960 (same shift on every face frame, 0 px relative drift preserved).
- kicks_squash snapped by dy=1 so the base sits on y=960.
- kicks_run_1 snapped by dy=2 so the base sits on y=960.
- kicks_run_2 snapped by dy=1 so the base sits on y=960.
- kicks_run_3 snapped by dy=1 so the base sits on y=960.

## Set notes

Shared set plus squash, air, and three run frames. Single shoe (group-poster pair is a scene variant).

## Idle measurement in this package

- Idle file: `kicks_happy.png`
- Foot / base y: 960 (spec target 960)
- Silhouette mean x: 512.5 (canvas centre 512)
- Margins L/T/R/B: (103, 50, 188, 63)

