from arms2 import *
import json
out={}
for n in names:
    m=np.load(f'mask_{n}.npy')
    if n=='wave_1': m|=ellipse(815,712,95,70)
    if n=='thinking':
        RV=visor_mask(R[n]); m|=cv2.erode((RV&NV).astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(15,15))).astype(bool)
    aNd=feather(cv2.dilate(armpart(N).astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(25,25))),2)
    mf=np.maximum(feather(m,6),aNd)
    o=composite(N,R[n],mf)
    dst={'thinking':'haggy_thinking'}.get(n,'haggy_'+n)
    save(o,f'frames/{dst}.png')
    np.save(f'maskf_{n}.npy',mf)
