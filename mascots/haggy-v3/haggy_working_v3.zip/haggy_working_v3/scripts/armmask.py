from lib import *
N=load(SRC+'haggy_eyes_open.png'); NV=visor_mask(N)
Y,X=np.mgrid[0:1024,0:1024]
def arm_mask(R, roi, thr=0.12, blur=5, grow=14):
    pn=N.copy(); pn[...,:3]*=pn[...,3:4]; pr=R.copy(); pr[...,:3]*=pr[...,3:4]
    d=np.abs(pn-pr).max(-1)
    d=cv2.GaussianBlur(d,(0,0),blur)
    m=(d>thr)&roi
    m=cv2.morphologyEx(m.astype(np.uint8),cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(31,31)))
    n,lab,st,_=cv2.connectedComponentsWithStats(m)
    keep=np.zeros_like(m)
    for i in range(1,n):
        if st[i,cv2.CC_STAT_AREA]>800: keep[lab==i]=1
    keep=ndi.binary_fill_holes(keep).astype(np.uint8)
    keep=cv2.dilate(keep,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*grow+1,2*grow+1)))
    return keep.astype(bool)&roi
