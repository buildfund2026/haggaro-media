import zipfile, io
from PIL import Image
from finalize_common import *
out=f'{V3}/haggy_working_v3.ora'
z=zipfile.ZipFile(out,'w')
z.writestr(zipfile.ZipInfo('mimetype'),'image/openraster',compress_type=zipfile.ZIP_STORED)
layers=[]
for n in reversed(ORDER):
    b=io.BytesIO(); Image.open(f'{V3}/{n}.png').save(b,'PNG',optimize=True)
    z.writestr(f'data/{n}.png',b.getvalue())
    vis='visible' if n=='haggy_neutral' else 'hidden'
    layers.append(f'  <layer name="{n}" src="data/{n}.png" x="0" y="0" opacity="1.0" visibility="{vis}"/>')
z.writestr('stack.xml','<?xml version="1.0" encoding="UTF-8"?>\n<image version="0.0.3" w="1024" h="1024">\n <stack>\n'+'\n'.join(layers)+'\n </stack>\n</image>\n')
b=io.BytesIO(); Image.open(f'{V3}/haggy_neutral.png').save(b,'PNG'); z.writestr('mergedimage.png',b.getvalue())
t=Image.open(f'{V3}/haggy_neutral.png'); t.thumbnail((256,256)); b=io.BytesIO(); t.save(b,'PNG'); z.writestr('Thumbnails/thumbnail.png',b.getvalue())
z.close()
