import sys; sys.path.insert(0,'/workspace/haggaro-marketing/mascots/haggy-master')
from build_master import remove_gray_bg
from arms2 import *
from arm import register
import json
src=sys.argv[1]
cut=remove_gray_bg(Image.open(src))
c=np.asarray(cut).astype(np.float32)/255
# initial scale/position from eyes_open raw->registered relationship: estimate by alpha bbox matching first
def bbox(a):
    ys,xs=np.nonzero(a[...,3]>0.5); return xs.min(),ys.min(),xs.max(),ys.max()
# use bottom (feet) + left paw extents (unchanged) and head top
bN=bbox(N); bc=bbox(c)
s=(bN[3]-bN[1])/(bc[3]-bc[1])
pre=shift(c,0,0,1.0)
M=np.array([[s,0,bN[0]-s*bc[0]],[0,s,bN[3]-s*bc[3]]],np.float32)
pm=c.copy(); pm[...,:3]*=pm[...,3:4]
o=cv2.warpAffine(pm,M,(1024,1024),flags=cv2.INTER_LANCZOS4); al=o[...,3:4]
o[...,:3]=np.where(al>1e-4,o[...,:3]/np.maximum(al,1e-4),0); o=np.clip(o,0,1)
R0,w=register(o)
print('pre-scale',s,'ecc',np.round(w,4).tolist())
save(R0,'reg_wave_0.png')
aR=armpart(R0); aN=armpart(N)
m=aN|aR|SHOULDER
m=cv2.dilate(m.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(25,25))).astype(bool)
mf=feather(m,6); np.save('maskf_wave_0.npy',mf)
save(composite(N,R0,mf),'frames/haggy_wave_0.png')
