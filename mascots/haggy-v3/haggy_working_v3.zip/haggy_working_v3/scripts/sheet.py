import json
from lib import *
from finalize_common import *
from PIL import ImageDraw, ImageFont
INTER="/usr/share/fonts/truetype/sand-box/google/Inter/Inter-VariableFont_opsz,wght.ttf"
def F(s,w=400):
    f=ImageFont.truetype(INTER,s)
    try: f.set_variation_by_axes([14 if s<20 else 32,w])
    except Exception: pass
    return f
M=json.load(open('metrics.json'))
T=360; PAD=16; COLS=6
def checker(w,h,s=16):
    y,x=np.mgrid[0:h,0:w]; c=((x//s+y//s)%2).astype(np.float32)
    return np.dstack([0.80+0.12*c]*3)
N=load(f'{V3}/haggy_neutral.png')
def outline(a,th=0.5,k=3):
    m=(a[...,3]>th).astype(np.uint8)
    return (m^cv2.erode(m,np.ones((k,k),np.uint8))).astype(bool)
Nout=cv2.dilate(outline(N).astype(np.uint8),np.ones((4,4),np.uint8)).astype(bool)
rows=(len(ORDER)+1+COLS-1)//COLS
W=COLS*T+(COLS+1)*PAD; H=120+rows*(T+56+PAD)+PAD
sheet=Image.new('RGB',(W,H),(24,20,32)); d=ImageDraw.Draw(sheet)
d.text((PAD,18),'Haggy — Pose Set v3 (17 frames)',font=F(40,700),fill=(255,255,255))
d.text((PAD,70),'1024×1024 transparent PNG · checkerboard = transparency · cyan line = idle (haggy_neutral) onion skin · red = the only area that differs from idle · creative prep only, not for publication',font=F(19),fill=(200,190,225))
cells=ORDER+['__onion']
for i,n in enumerate(cells):
    cx=PAD+(i%COLS)*(T+PAD); cy=120+(i//COLS)*(T+56+PAD)
    if n=='__onion':
        bg=np.dstack([np.full((1024,1024),v) for v in (0.12,0.10,0.16)])
        cols=[(1,0.4,0.4),(0.4,1,0.5),(0.4,0.7,1),(1,0.9,0.3),(1,0.5,1),(0.4,1,1)]
        for j,m in enumerate(ORDER):
            a=load(f'{V3}/{m}.png'); o=cv2.dilate(outline(a).astype(np.uint8),np.ones((4,4),np.uint8)).astype(bool)
            bg[o]=bg[o]*0.3+np.array(cols[j%6])*0.7
        bg[959:962,:]=[0.3,0.9,0.4]; bg[:,511:514]=[0.9,0.3,0.3]
        tile=Image.fromarray((bg*255).astype(np.uint8)).resize((T,T),Image.LANCZOS)
        sheet.paste(tile,(cx,cy))
        d.text((cx,cy+T+6),'Onion skin, all 17 outlines',font=F(20,600),fill=(255,255,255))
        d.text((cx,cy+T+30),'red x=512 · green feet line y=960',font=F(16),fill=(190,180,215))
        continue
    a=load(f'{V3}/{n}.png')
    bg=checker(1024,1024,24)
    rgb=a[...,:3]*a[...,3:4]+bg*(1-a[...,3:4])
    diff=np.abs((a*255).round()-(N*255).round()).max(-1)>0
    dm=(cv2.GaussianBlur(diff.astype(np.float32),(0,0),4)>0.08).astype(np.uint8)
    dm=cv2.morphologyEx(dm,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(31,31)))
    dm=ndi.binary_fill_holes(dm).astype(np.uint8)
    dif_edge=(dm^cv2.erode(dm,np.ones((7,7),np.uint8))).astype(bool)
    rgb[Nout]=[0.0,0.85,1.0]
    rgb[dif_edge]=[1,0.15,0.2]
    tile=Image.fromarray((np.clip(rgb,0,1)*255).astype(np.uint8)).resize((T,T),Image.LANCZOS)
    sheet.paste(tile,(cx,cy))
    af=M[n]['after_v3']; mx=max(v[2] for v in af.values())
    d.text((cx,cy+T+6),f'{LABEL[n]}',font=F(20,600),fill=(255,255,255))
    d.text((cx,cy+T+30),f'{n}.png · body/head Δ {mx:.2f} px',font=F(15),fill=(190,180,215))
sheet.save(f'{V3}/haggy_poses_v3_review_sheet.png',optimize=True)
sheet.convert('RGB').save(f'{V3}/haggy_poses_v3_review_sheet.jpg',quality=88)
print(sheet.size)
