# Spike — official pose set

Approved official by Gerson Moreno on 18 November 2026, 9:15 AM America/Chicago (CST).

Creative development only. These files are for the login-page preview and animation work (spec-c).
Nothing is to be published, pushed, integrated, or deployed until the founder approves that step.
Coming 2027.

## Files

Each pose is a 1024×1024 32-bit sRGB PNG with a transparent background: no card, no ground shadow, no outer glow.
Names are lower_snake, character first.

- `spike_neutral.png` — Neutral (glasses on, calmer smile)
- `spike_sunglasses_on.png` — Sunglasses on (official / hero / resting)
- `spike_happy.png` — Happy
- `spike_surprised.png` — Surprised
- `spike_sunglasses_down.png` — Sunglasses down (eyes peeking)
- `spike_sunglasses_up.png` — Sunglasses up (on cap) — also packaged as spike_glasses_up.png (spec-c name)
- `spike_glasses_up.png` — spec-c name; identical pixels to `spike_sunglasses_up.png`.

Working file: `spike_working.ora` (one layer per pose).
Contact sheet: `spike_poses_sheet.png`.

## Registration

Canvas 1024×1024, never trimmed. Feet or base rest on y=960 (64 px from the bottom) unless a 48 px top margin would be broken (noted below).
The page does the travelling. Body-changing poses stay planted on that baseline.

## Package registration notes (copies only)

Approved source masters were not rewritten. Fixes below were applied only to the files in this package.

- Official hero (spike_sunglasses_on) snapped by dy=1 so the pot base sits on y=960.
- Package copies were translated so the pot (the non-moving lock) lines up with the official hero and the base sits on y=960. Integer shifts: {'spike_neutral': (4, -2), 'spike_happy': (5, -2), 'spike_surprised': (5, 2), 'spike_sunglasses_down': (8, 1), 'spike_sunglasses_up': (7, 0)}. Artwork was not redrawn or rescaled. Sunglasses-down / up are moving-part poses, so residual silhouette difference around the glasses is expected.

## Set notes

Approved sunglasses_on / _down / _up names are kept. spike_glasses_up.png is a spec-c alias of sunglasses_up (identical pixels).

## Skipped (not invented)

- spike_blink_half / blink_closed / look_left / look_right — skipped (spec-c allows this when sunglasses hide the eyes).
- spike_laugh / spike_adjust / spike_grin — listed in spec-c, not in the approved set; not invented.

## Idle measurement in this package

- Idle file: `spike_sunglasses_on.png`
- Foot / base y: 960 (spec target 960)
- Silhouette mean x: 527.8 (canvas centre 512)
- Margins L/T/R/B: (214, 58, 160, 63)

