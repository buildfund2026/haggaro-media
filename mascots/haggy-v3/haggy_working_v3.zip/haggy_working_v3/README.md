# Haggy pose set v3 (fixes requested on v2)

Creative prep only. **Do not publish, integrate, merge or deploy.** The official master (approved by Gerson on 16 Nov 2026, small black backpack included; round open eyes for idle, upward crescent eyes for happy) is unchanged. v2 (`../poses/`, `../poses_sheet.png`, etc.) is left untouched.

Follows spec v2 (16 Nov 2026), "Corrections requested on Pose Set v2", with the spec's file names.

## Deliverable

- `haggy_poses_v3.zip`: the 17 PNGs only, in a `haggy/` folder (one folder per character, as the spec asks).
- `haggy_poses_v3_review_sheet.png` / `.jpg`: contact sheet on a checkerboard. Cyan = idle onion skin, red = the only area that differs from idle. Last tile = all 17 outlines with the x=512 centre and the y=960 feet line.
- `preview.mp4`: 17 s, 12 fps, frame swaps only: idle → blink → look L/R → idle → wave_0 → wave_1–4 → back via wave_0 → expressions.
- `manifest.json`: per-frame sha256, size, bbox, margins, changed region, before/after offsets and shadow check.
- `haggy_working_v3.ora`: working file (OpenRaster, one layer per pose; opens in Krita/GIMP). `haggy_working_v3.zip` = working file + build scripts + masks + the wave_0 render.

## Files (17)

`haggy_neutral, haggy_blink_half, haggy_blink_closed, haggy_look_left, haggy_look_right, haggy_wave_0 (new), haggy_wave_1, haggy_wave_2, haggy_wave_3, haggy_wave_4, haggy_happy, haggy_laugh, haggy_wink, haggy_surprised, haggy_thinking, haggy_sad, haggy_heart` (`.png`)

Renamed from v2 to match the spec: eyes_open → `haggy_neutral`, eyes_half → `haggy_blink_half`, eyes_closed → `haggy_blink_closed`, heart_eyes → `haggy_heart`.

## What changed

1. **One idle body in every frame.** v2 frames were separate renders lined up by the chest badge, so the bodies were not identical (thinking was rendered ~1.3% smaller). In v3 `haggy_neutral` is the master. Each other frame is the neutral frame with only the part that changes replaced in the artwork: the face (visor) for blink/look/expressions, the right arm and hand for the waves, and face plus hand-on-chin for thinking. Head, hood, headphones, torso, legs, feet and left paw are **pixel-identical** to neutral in all 17 files, so the flip test cannot jump.
2. **Look left / right / thinking / sad re-registered.** Offsets measured against idle with OpenCV ECC on head (face masked out), torso and feet. Changing areas were masked out. Values are px distance, head / torso / feet:

| File | Pose | v2 before | v3 after |
| --- | --- | --- | --- |
| `haggy_neutral.png` | Neutral / idle | 0.00 / 0.00 / 0.00 | 0.00 / 0.00 / 0.00 |
| `haggy_blink_half.png` | Blink half | 0.58 / 0.40 / 0.26 | 0.00 / 0.00 / 0.00 |
| `haggy_blink_closed.png` | Blink closed | 0.46 / 0.18 / 0.11 | 0.00 / 0.00 / 0.00 |
| `haggy_look_left.png` | Look left | 10.76 / 6.71 / 2.48 | 0.00 / 0.00 / 0.00 |
| `haggy_look_right.png` | Look right | 9.22 / 2.56 / 4.14 | 0.00 / 0.00 / 0.00 |
| `haggy_wave_0.png` | Wave 0 (new) | new frame | 0.00 / 0.00 / 0.00 |
| `haggy_wave_1.png` | Wave 1 start | 5.37 / 3.61 / 2.10 | 0.00 / 0.00 / 0.00 |
| `haggy_wave_2.png` | Wave 2 mid | 1.00 / 0.97 / 0.74 | 0.00 / 0.00 / 0.00 |
| `haggy_wave_3.png` | Wave 3 peak | 0.26 / 0.40 / 0.43 | 0.00 / 0.00 / 0.00 |
| `haggy_wave_4.png` | Wave 4 swing | 1.36 / 1.28 / 1.33 | 0.00 / 0.00 / 0.00 |
| `haggy_happy.png` | Happy | 1.76 / 1.44 / 1.07 | 0.00 / 0.00 / 0.00 |
| `haggy_laugh.png` | Laugh | 0.94 / 0.37 / 0.19 | 0.00 / 0.00 / 0.00 |
| `haggy_wink.png` | Wink | 0.36 / 0.40 / 0.70 | 0.00 / 0.00 / 0.00 |
| `haggy_surprised.png` | Surprised | 1.65 / 0.42 / 0.46 | 0.00 / 0.00 / 0.00 |
| `haggy_thinking.png` | Thinking | 17.32 / 15.26 / 14.62 | 0.00 / 0.00 / 0.00 |
| `haggy_sad.png` | Sad (held) | 6.79 / 1.09 / 2.71 | 0.00 / 0.00 / 0.00 |
| `haggy_heart.png` | Heart eyes (held) | 0.74 / 0.62 / 0.32 | 0.00 / 0.00 / 0.00 |

   Look left/right are now an eye-direction look only. The small v2 head turn (which moved the head ~9–11 px) is gone. The page's tilt can add a turn if wanted.
3. **Surprised ground shadow removed.** Surprised now uses the idle body, so the dark gray contact shadow under the soles is gone. Check on all 17: no alpha outside 3 px of the solid silhouette; 0 transparent-edge pixels on the canvas border; gray-dark pixels below y=907 = 2,127 in every frame, identical to idle (sneaker sole outline and paw, not shadow). v2 surprised was 9,323 there. There's no card, no background and no outer glow (the eye glow painted on the visor is part of the face).
4. **New `haggy_wave_0.png`.** It sits between idle and wave_1: the arm is lowered and the open palm-up mitten hovers beside the knee, above the sneaker without touching it. Hand centre is about 70% of the way from idle to wave_1 vertically and still out to the side like idle, so the drop to wave_1 reads as one motion. The arm comes from a new reference render of the approved idle + wave_1 (5 candidates; 1 kept), registered to the idle body and pasted onto the idle frame. Face, head and body are the idle pixels, so there's no identity drift.
5. **Placement per spec.** The whole set moved by one whole-pixel offset (-80 px x, +2 px y, lossless and identical for every frame) so the idle character is centred left to right (alpha x 140–882) and the feet rest on the line 64 px above the bottom (last solid row 959). Minimum margins: left 140, top 142, right 124 (wave_4), bottom 62. **Note for Claude:** this moves Haggy relative to v2 inside the canvas. The preview's corner placement may need re-checking.
6. **Edges.** Faint (<6% alpha) haze more than 3 px outside the silhouette was cleared. RGB is zero wherever alpha is zero.

## Known limits

- The source art was rendered on a flat gray studio backdrop and keyed out with colour unmixing, not rendered on transparency. That's the same as v2, and there's no purple and no visible fringe. A true transparent re-render would need a 3D source we don't have.
- The faces in look, sad, happy etc. are the v2 expression art, the same approved designs. Wave frames now use the idle face (open eyes, calm smile), so wave_1's slightly wider v2 smile is replaced by the idle smile.
- WebP 512/256 exports are not included: spec v2 says the 1024 masters are enough and the page builds one small sheet. Estimate: all 17 at 256 px in one WebP sheet ≈ 150 KB (q80) / 211 KB (q90), under the 400 KB target.
- Separate part layers are not exported. The spec says that isn't needed now.
