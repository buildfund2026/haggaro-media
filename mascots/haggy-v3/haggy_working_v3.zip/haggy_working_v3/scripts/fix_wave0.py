from arms2 import *
R0=load('reg_wave_0.png')
aR=armpart(R0); aN=armpart(N)
m=aN|aR|SHOULDER
m=cv2.dilate(m.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(25,25))).astype(bool)
# neutral right sneaker/leg region (keep neutral there)
L=(N[...,3]>0.5)&(Y>=690)&(X>=600)&~aN
L=cv2.morphologyEx(L.astype(np.uint8),cv2.MORPH_OPEN,np.ones((9,9),np.uint8)).astype(bool)
Ld=cv2.dilate(L.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(9,9))).astype(bool)
mf=feather(m&~Ld,5)*(1-feather(L,3))
aNd=feather(cv2.dilate(aN.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(25,25))),2)*(1-feather(L,3))
mf=np.maximum(mf,aNd)
o=composite(N,R0,np.clip(mf,0,1))
# hand over sneaker: dark mitten pixels of R0 near the sneaker
hand=(lum(R0)<0.2)&(R0[...,3]>0.5)&(X>=740)&(Y>=600)&(Y<=800)
n_,lab,st,_=cv2.connectedComponentsWithStats(hand.astype(np.uint8))
k=np.zeros_like(hand)
for i in range(1,n_):
    if st[i,cv2.CC_STAT_AREA]>2000: k|=lab==i
k=cv2.morphologyEx(k.astype(np.uint8),cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(21,21)))
k=ndi.binary_fill_holes(k)&(R0[...,3]>0.02)
k=cv2.dilate(k.astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool)
hm=feather(k,1.0)*R0[...,3]
pr=R0.copy(); pr[...,:3]*=pr[...,3:4]
po=o.copy(); po[...,:3]*=po[...,3:4]
h=hm[...,None]
src=np.dstack([R0[...,:3]*hm[...,None],hm])
outp=src+po*(1-h)
al=outp[...,3:4]; outp[...,:3]=np.where(al>1e-4,outp[...,:3]/np.maximum(al,1e-4),0)
save(np.clip(outp,0,1),'frames/haggy_wave_0.png')
np.save('maskf_wave_0.npy',np.maximum(mf,hm))
