import os, json, shutil, subprocess, hashlib
from lib import *
from measure import measure, alpha_stats
from PIL import ImageDraw, ImageFont
V3='/workspace/haggaro-marketing/mascots/haggy-master/v3'
ORDER=['haggy_neutral','haggy_blink_half','haggy_blink_closed','haggy_look_left','haggy_look_right',
 'haggy_wave_0','haggy_wave_1','haggy_wave_2','haggy_wave_3','haggy_wave_4',
 'haggy_happy','haggy_laugh','haggy_wink','haggy_surprised','haggy_thinking','haggy_sad','haggy_heart']
V2NAME={'haggy_neutral':'haggy_eyes_open','haggy_blink_half':'haggy_eyes_half','haggy_blink_closed':'haggy_eyes_closed','haggy_heart':'haggy_heart_eyes'}
LABEL={'haggy_neutral':'Neutral / idle','haggy_blink_half':'Blink half','haggy_blink_closed':'Blink closed','haggy_look_left':'Look left','haggy_look_right':'Look right',
 'haggy_wave_0':'Wave 0 (NEW in-between)','haggy_wave_1':'Wave 1 start','haggy_wave_2':'Wave 2 mid','haggy_wave_3':'Wave 3 peak','haggy_wave_4':'Wave 4 swing',
 'haggy_happy':'Happy','haggy_laugh':'Laugh','haggy_wink':'Wink','haggy_surprised':'Surprised','haggy_thinking':'Thinking','haggy_sad':'Sad (held)','haggy_heart':'Heart eyes (held)'}
CHANGE={'face':'eyes/mouth only (visor)','arm':'right arm only','face+arm':'face + right arm/hand','none':'reference'}
KIND={n:'face' for n in ORDER}; KIND['haggy_neutral']='none'
for n in ['haggy_wave_0','haggy_wave_1','haggy_wave_2','haggy_wave_3','haggy_wave_4']: KIND[n]='arm'
KIND['haggy_thinking']='face+arm'
# --- placement: integer shift, identical for all frames (lossless) ---
N=load('frames/haggy_neutral.png')
ys,xs=np.nonzero(N[...,3]>0.5)
DX=int(round(512-(xs.min()+xs.max()+1)/2)); DY=int(959-ys.max())
print('shift',DX,DY)
def ishift(a,dx,dy):
    o=np.zeros_like(a)
    H,W=a.shape[:2]
    o[max(dy,0):H+min(dy,0),max(dx,0):W+min(dx,0)]=a[max(-dy,0):H-max(dy,0),max(-dx,0):W-max(dx,0)]
    return o
frames={}
for n in ORDER:
    a=load(f'frames/{n}.png'); a=ishift(a,DX,DY)
    # hard-clean: zero RGB where alpha==0, quantize
    solid=a[...,3]>=0.9
    ring=cv2.dilate(solid.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(7,7))).astype(bool)
    faint=(a[...,3]<0.06)&~ring
    a[faint]=0
    a[a[...,3]<0.5/255]=0
    frames[n]=a
    Image.fromarray((np.clip(a,0,1)*255+0.5).astype(np.uint8),'RGBA').save(f'{V3}/{n}.png',optimize=True)
json.dump(dict(dx=DX,dy=DY),open('shift.json','w'))
