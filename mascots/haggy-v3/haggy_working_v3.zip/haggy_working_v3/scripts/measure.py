import cv2, numpy as np, sys, json
from PIL import Image
def load(p):
    a=np.asarray(Image.open(p).convert('RGBA')).astype(np.float32)/255
    return a
def gray(a):
    rgb=a[...,:3]*a[...,3:4]+0.5*(1-a[...,3:4])
    g=cv2.cvtColor((rgb*255).astype(np.uint8),cv2.COLOR_RGB2GRAY).astype(np.float32)/255
    # add alpha edge info
    return 0.6*g+0.4*a[...,3]
REG={
 'head':  (lambda X,Y:(Y>=130)&(Y<=560)&(X<720)),
 'torso': (lambda X,Y:(Y>=580)&(Y<=760)&(X>=360)&(X<=720)),
 'legs':  (lambda X,Y:(Y>=740)&(Y<=975)),
}
Y,X=np.mgrid[0:1024,0:1024]
def ecc(ref,mov,mask):
    w=np.eye(2,3,dtype=np.float32)
    crit=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,200,1e-6)
    try:
        _,w=cv2.findTransformECC(ref,mov,w,cv2.MOTION_TRANSLATION,crit,mask.astype(np.uint8),5)
    except cv2.error as e:
        return None
    return float(w[0,2]),float(w[1,2])
def measure(refp,movp):
    r=gray(load(refp)); m=gray(load(movp)); out={}
    ra=load(refp)[...,3]
    for k,f in REG.items():
        msk=f(X,Y)&(cv2.dilate((ra>0.05).astype(np.uint8),np.ones((15,15)))>0)
        out[k]=ecc(r,m,msk)
    return out
def alpha_stats(p):
    a=load(p); al=a[...,3]
    ys,xs=np.nonzero(al>0.05)
    feet = al[900:1024]
    # semi-transparent dark pixels anywhere below y=880
    rgb=a[...,:3]; lum=rgb.mean(-1)
    semi=(al>0.02)&(al<0.85)&(lum<0.25)
    return dict(bbox=[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())],
        semi_dark_px_total=int(semi.sum()), semi_dark_below_900=int(semi[900:].sum()),
        alpha_px_below_962=int((al[962:]>0.02).sum()),
        corners=[float(al[0,0]),float(al[0,-1]),float(al[-1,0]),float(al[-1,-1])])
if __name__=='__main__':
    ref=sys.argv[1]
    for p in sys.argv[2:]:
        m=measure(ref,p); s=alpha_stats(p)
        fmt=lambda v:'fail' if v is None else f'({v[0]:+.2f},{v[1]:+.2f}) {np.hypot(*v):.2f}'
        print(p.split('/')[-1].ljust(24),' '.join(f'{k}={fmt(v)}' for k,v in m.items()), s)
